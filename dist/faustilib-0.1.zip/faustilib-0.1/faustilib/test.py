import os, sys, time, zipfile
from datetime import datetime


class test():
	def ahora():
		print(datetime.now())
